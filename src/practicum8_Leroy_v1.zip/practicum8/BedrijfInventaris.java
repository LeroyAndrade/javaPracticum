package practicum8;
import java.util.ArrayList;
import java.util.List;

public class BedrijfInventaris {
    private String bedrijfsNaam;
    private double budget;
    private ArrayList<Goed> alleGoederen = new ArrayList<Goed>();

    public BedrijfInventaris() {
        this.alleGoederen = new ArrayList<>();
    }

    public BedrijfInventaris(String nm) {
        this.bedrijfsNaam = nm;
        this.alleGoederen = new ArrayList<>();
    }

    public BedrijfInventaris(double bud) {
        this.budget = bud;
        this.alleGoederen = new ArrayList<>();
    }

    public BedrijfInventaris(String nm, double bud) {
        this.bedrijfsNaam = nm;
        this.budget = bud;
        this.alleGoederen = new ArrayList<>();
    }

//    public void setBudget(double budget) {
//        this.budget = budget;
//    }

    public double getBudget() {
        return budget;
    }

    public void schafAan(Goed g){
        if (alleGoederen.contains(g)) {
            System.out.println("Product reeds toegevoegd");
            return;
        }

        if (budget >= g.huidigeWaarde()) {
            if (!alleGoederen.contains(g)) {
                alleGoederen.add(g);
                budget -= g.huidigeWaarde();
            } else {
                System.out.println("Product reeds toegevoegd");
            }
        } else {
            System.out.println("Geen saldo: "+budget);
        }
    }



    public List<Goed> getAlleGoederen() {
        return alleGoederen;
    }

    public double getTotaleNieuwprijs() {
        double totaal = 0;
        for (Goed g : alleGoederen) {
            if (g instanceof Voertuig) {
                budget -= ((Voertuig) g).getNieuwprijs();
            }
        }
        return totaal;
    }

    @Override
    public String toString() {
        String inventarisTotaal = "";

        for (Object key : alleGoederen) {
            inventarisTotaal += "Inventory: - " + key + "\n" + alleGoederen + getTotaleNieuwprijs() + "Huidigbudget: - " + getBudget()+"\n";
        }
        return inventarisTotaal;
    }
}
