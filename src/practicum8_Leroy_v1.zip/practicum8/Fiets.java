package practicum8;

public class Fiets extends Voertuig {
    int framenummer;

    public Fiets(String tp, double pr, int jr, int fnr) {
        super(tp, pr, jr);
        framenummer = fnr;
    }

    public double huidigeWaarde() {
    return framenummer;
    }

    public String toString() {
        return "Fiets: type=" + ", prijs=" + nieuwprijs + ", jaar=" + bouwjaar + ", framenummer=" + framenummer;
    }

    @Override
    public boolean equals(Object anderObject) {
        boolean gelijkeObjecten = false;

        if (anderObject instanceof Fiets) {
            Fiets anderFiets = (Fiets) anderObject;

            if (this.framenummer == anderFiets.framenummer) {
                gelijkeObjecten = true;
            }
        }
        return gelijkeObjecten;
    }
}