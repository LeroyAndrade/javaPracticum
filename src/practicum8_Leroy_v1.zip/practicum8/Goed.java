package practicum8;

public interface Goed {
     double huidigeWaarde();
}
